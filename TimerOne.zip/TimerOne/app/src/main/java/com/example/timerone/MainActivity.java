package com.example.timerone;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    /*plugins / imports
    -- Datepicker, timerrpicker
    -- Calendar
     */

    //Variables
    TextView tvSetTime;
    Button btnSetter;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvSetTime = findViewById(R.id.textView1);
        btnSetter = findViewById(R.id.button1);

        btnSetter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDateTime();
            }
        });



    }
    //method
    private void showDateTime(){
        final Calendar currentDate = Calendar.getInstance();
        //format D/M/Y --> Y/M/D
        int year = currentDate.get(Calendar.YEAR);
        int month = currentDate.get(Calendar.MONTH);
        int day = currentDate.get(Calendar.DAY_OF_MONTH);


        //datePicker
        DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int selectedYear, int selectedMonth, int selectedDayofMonth) {
                final  Calendar time = Calendar.getInstance();
                int hour = time.get(Calendar.HOUR_OF_DAY);
                int minute = time.get(Calendar.MINUTE);

                //Timer Picker GUI
                TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minuteOfDay) {
                        Calendar dateTime = Calendar.getInstance();
                        dateTime.set(selectedYear,selectedMonth,selectedDayofMonth,hourOfDay,minuteOfDay);
                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                        //show up in the textview
                        tvSetTime.setText(dateFormat.format(dateTime.getTime()));

                    }
                },hour,minute,true);
                timePickerDialog.setTitle("Choose time: ");
                timePickerDialog.show();
                }
        }, year, month, day);
                datePickerDialog.setTitle("Select Date");
                datePickerDialog.show();
    }//method end
}//main end