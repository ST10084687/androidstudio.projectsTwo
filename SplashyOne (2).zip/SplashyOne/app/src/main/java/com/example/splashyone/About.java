package com.example.splashyone;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class About extends AppCompatActivity {

    //variables
    TextView abtText;
    ImageView imgLogoTwo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        abtText=findViewById(R.id.textView2);
        imgLogoTwo=findViewById(R.id.imageView2);


    }
}