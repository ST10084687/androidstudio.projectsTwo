package com.example.splashyone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    //variables
    TextView tvHeading;
    ImageView imgLogo;
    long delay = 8000; //splash timing

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //typecasting
        tvHeading=findViewById(R.id.textView);
        imgLogo=findViewById(R.id.imageView3);

        //splash code
        //create a timer obj
        Timer RunSplash = new Timer();
        //add the timer task obj
        TimerTask ShowSplash = new TimerTask() {
            @Override
            public void run() {
                finish();//using the delay

                //move onto the next screen
                Intent intentSplash = new Intent(MainActivity.this,About.class);
                startActivity(intentSplash);
            }
        };
        RunSplash.schedule(ShowSplash,delay);
    }
}