package com.example.appthreeb;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //variables
    TextView tvHeading;
    ImageView background;
    Button btnEnter;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvHeading = findViewById(R.id.textView);
        background = findViewById(R.id.imageView);
        btnEnter = findViewById(R.id.button);

    }
    //method to move to the new screen
    public void enterBtnMethod(View view)
    {
        // Intent service --
        // context -- this --> name of the class you want to move to
        Intent intent = new Intent(this,Landing.class);
        //start the intent service -- pass the obj into it
        startActivity(intent);

    }
}