package com.example.lapping;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    TextView tvTime;
    TextView tvLapTime;
    Button btnStartStop;
    Button btnReset;
    Button lap;

    private LineChart chart;
    int lapNumber = 1;
    List<Long> lapTimes = new ArrayList<>();
    //Stopwatches
    Handler handler;
    Runnable runnable;
    //to track the times
    boolean isRunning;
    long startTime;
    long elapsedTime;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvTime = findViewById(R.id.tvTime);
        tvLapTime = findViewById(R.id.tvlapTime);
        btnStartStop = findViewById(R.id.btnStartStop);
        btnReset = findViewById(R.id.btnReset);
        lap = findViewById(R.id.Lap);


        chart = findViewById(R.id.chart);

        //set up the chart properties
        chart.getDescription().setEnabled(true);
        chart.setDrawGridBackground(true);
        chart.getAxisLeft().setEnabled(true);
        chart.getAxisRight().setEnabled(true);
        chart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);


        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                elapsedTime = System.currentTimeMillis() - startTime;
                //formatting needed    hh:mm:ss:ss
                tvTime.setText(formatTime(elapsedTime));
                handler.postDelayed(this, 100);

            }
        };
    }//on create end
    public void startStopWatch (View view){
        if (!isRunning)
        {
            isRunning = true;
            startTime = System.currentTimeMillis();
            handler.postDelayed(runnable, 0);
            btnStartStop.setText("STOP");

            //optional
            lapNumber = 1;
            lapTimes.clear();
            tvLapTime.setText("");
        }
        else
        {
            //stop the clock code or method should go here
            stopStopWatch();
        }
        } //meth ends
    public String formatTime (long elapsedTime){
        // hh:mm:ss:ss
        int hours = (int) (elapsedTime / (1000 * 60 * 60));
        int minutes = (int) ((elapsedTime / (1000 * 60 )) % 60);
        int seconds = (int) ((elapsedTime / 1000) % 60);
        int milliseconds  = (int) (elapsedTime % 1000);
        return String.format(Locale.getDefault(), "%02d:%02d:%02d:%03d",
                hours, minutes, seconds, milliseconds);


    }//ends method
    public void stopStopWatch()
    {
        isRunning = false;
        handler.removeCallbacks(runnable);//clears the handler
        btnStartStop.setText("START");

        //Add the lap times to the list and get it to display
        long lapTime = System.currentTimeMillis() - startTime;
        lapTimes.add(lapTime);

        //the display
        String lapTimeString =  "Lap: " + lapNumber + " : " + formatTime(lapTime);
        tvLapTime.setText(tvLapTime.getText() + "\n" + lapTimeString);
    }//ends meth
    public void resetWatch (View view){
        isRunning = false;
        handler.removeCallbacks(runnable); //clears the handler
        tvTime.setText("00:00:00:00");
        btnStartStop.setText("START");

        //optional
        lapNumber = 1;
        lapTimes.clear();
        tvLapTime.setText("");
    }

    //lap method
    public void lapButton (View view){
        if(isRunning){
            long lapTime = System.currentTimeMillis() - startTime;
            lapTimes.add(lapTime);

            //the display
            String lapTimeString =  "Lap: " + lapNumber + " : " + formatTime(lapTime);
            tvLapTime.setText(tvLapTime.getText() + "\n" + lapTimeString);
            lapNumber++;

            //Insert CHART AFTER LAP DATA RENDERS
            //Create an entry for  the lap times and add to a list
            Entry entry =new Entry(lapNumber, (float) lapTime);
            List<Entry> entries = new ArrayList<>();
            entries.add(entry);
            //now create a line data set
            LineDataSet lineDataSet = new LineDataSet(entries, "Lap Times");
            lineDataSet.setDrawIcons(false);
            lineDataSet.setColor(Color.RED);
            lineDataSet.setCircleColor(Color.RED);
            lineDataSet.setLineWidth(2f);
            lineDataSet.setCircleRadius(3f);
            lineDataSet.setValueTextSize(9);
            lineDataSet.setDrawValues(false);


            //pass into the chart
            LineData ld = chart.getData();
            if (ld==null)
            {
                ld=new LineData(lineDataSet);
                chart.setData(ld);
            }
            else {
                ld.addDataSet(lineDataSet);
                chart.notifyDataSetChanged();
            }
            //optional --> max number of lines on graph
            chart.setVisibleXRangeMaximum(5);
            chart.moveViewToX(lapNumber -5);



        }else {
            //knock yourself out

        }
        }
    }


