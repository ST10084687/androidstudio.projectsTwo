package com.example.sqlonebasic

import android.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Message
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    //pull the db helper class
    private lateinit var myDb: DatabaseHelper

    //variables -- eds and btns
    private lateinit var edName: EditText
    private lateinit var edSurname: EditText
    private lateinit var edMarks: EditText
    private lateinit var edId: EditText

    private lateinit var btnAdd: Button
    private lateinit var btnView: Button
    private lateinit var btnUpdate: Button
    private lateinit var btnDelete: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //typecasting
        myDb = DatabaseHelper(this)


        edId = findViewById(R.id.editTextTextPersonName3)
        edName = findViewById(R.id.editTextTextPersonName4)
        edSurname = findViewById(R.id.editTextTextPersonName5)
        edMarks = findViewById(R.id.editTextTextPersonName6)

        btnAdd = findViewById(R.id.button)
        btnView = findViewById(R.id.button2)
        btnUpdate = findViewById(R.id.button3)
        btnDelete = findViewById(R.id.button4)

    }

    //to control
    fun addData(view: View) {
        val isInserted = myDb.insertData(
            edName.text.toString(),
            edSurname.text.toString(),
            edMarks.text.toString().toInt()

        )
        if (isInserted) {
            Toast.makeText(this, "Entry added", Toast.LENGTH_SHORT)
        } else {
            Toast.makeText(this, "Failed to add entry", Toast.LENGTH_SHORT)

        }
    }

    //show data
    private fun showMessage(title: String, message: String) {
        //string builder --> alert db
        var builder = AlertDialog.Builder(this)
        builder.setCancelable(true)
        builder.setTitle(title)
        builder.setMessage(message)
        builder.show()
    }

    //to be passed into a button click event
    fun viewAll(view: View) {
        val res = myDb.getAllData()
        //optional if else
        if (res.count == 0) {
            showMessage("Error - no entries in db", "")
            return
        }
        //if theres data --> append method
        val buffer = StringBuffer()

        while (res.moveToNext()){
        //as long as there is a next entry /line keep reading
        buffer.append("ID: ${res.getString(0)}\n")
        buffer.append("Name: ${res.getString(1)}\n")
        buffer.append("Surname: ${res.getString(2)}\n")
        buffer.append("Marks: ${res.getInt(3)}\n")

    }
    showMessage("Data", buffer.toString())
}
    //Update database
    fun updateData(view: View){
        val isUpdate = myDb.updateData(
            edId.text.toString(),
            edName.text.toString(),
            edSurname.text.toString(),
            edMarks.text.toString().toInt()
        )

        if (isUpdate){
            Toast.makeText(this, "Entry Added", Toast.LENGTH_SHORT)
        } else {
            Toast.makeText(this, "Failed to update entry", Toast.LENGTH_SHORT)
        }
    }
    //final method --> delete entry
    fun deleteData (view: View){
        val deletedRows = myDb.deleteData(edId.text.toString())

        //optional checks if else
        if (deletedRows > 0)
        {
            Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT)
        } else
        {
            Toast.makeText(this, "Cannot be deleted", Toast.LENGTH_SHORT)
        }
    }
}