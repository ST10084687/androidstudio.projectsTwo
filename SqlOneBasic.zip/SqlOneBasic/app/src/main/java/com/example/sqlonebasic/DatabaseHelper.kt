package com.example.sqlonebasic

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper



class DatabaseHelper (context : Context) : SQLiteOpenHelper (context, DATABASE_NAME, null, 1) {
    //data objects --> db name , table name etc

    companion object{
        private const val DATABASE_NAME = "Student.db" //db name
        private const val TABLE_NAME = "Students_table" //table name
        private const val COL_1 = "ID"
        private const val COL_2 = "Name"
        private const val COL_3 = "Surname"
        private const val COL_4 = "Marks"

    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE $TABLE_NAME (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "NAME TEXT, SURNAME TEXT, MARKS INTEGER )")
    }

    override fun onUpgrade(db : SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        //DELETE OLD VERSION
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    //insert data into table method
    fun insertData (name: String, surname: String, marks: Int) : Boolean {
        val db = this.writableDatabase
        //content values -- cursor --> sql lite requirements
        val contentValues = ContentValues()
        //place values into a column
        contentValues.put(COL_2, name)
        contentValues.put(COL_3, surname)
        contentValues.put(COL_4, marks)
        val result = db.insert(TABLE_NAME, null, contentValues)
        return result != -11L //pass / fail


    }
    //delete method
    fun deleteData (ID: String) : Int {
        val db = this.writableDatabase
        return db.delete(TABLE_NAME, "ID = ?", arrayOf(ID))
    }
    //select all method
    fun getAllData() : Cursor{
        val db = this.writableDatabase
        return db.rawQuery("SELECT * FROM $TABLE_NAME", null)
    }
    //method to update db instance
    fun updateData (ID: String, name: String, surname: String, marks: Int) : Boolean
    {
        // ?!
        val db = this.writableDatabase
        val contentValues = ContentValues()


        //place values into a column -- from the insert method
        contentValues.put(COL_1, ID)
        contentValues.put(COL_2, name)
        contentValues.put(COL_3, surname)
        contentValues.put(COL_4, marks)
        db.update(TABLE_NAME, contentValues, "ID=?", arrayOf(ID))
        return true

    }

}

