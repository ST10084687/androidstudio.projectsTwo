package com.example.notificationsone

import android.content.Intent
import android.content.Intent.ACTION_VIEW
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    //variables
    private lateinit var phoneNumber: EditText
    private lateinit var smsBody: EditText
    private lateinit var smsManager: Button
    private lateinit var smsIntent: Button
    private lateinit var smsView: Button
    private lateinit var text: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        phoneNumber = findViewById(R.id.phoneNumber)
        smsBody = findViewById(R.id.editTextTextPersonName2)
        smsManager = findViewById(R.id.button)
        smsIntent = findViewById(R.id.button2)
        smsView = findViewById(R.id.button4)
        text = findViewById(R.id.text)

        //set onclick
        smsIntent.setOnClickListener {
            sendByIntent()
        }




    }
    //methiod to handle sent by intent
    private fun sendByIntent (){

        val uri = Uri.parse("sms to: ${phoneNumber.text.toString()}")
        val smsIntent = Intent (Intent.ACTION_SENDTO, uri)
        smsIntent.putExtra("smsBody", smsBody.text.toString())

        try {
            startActivity(smsIntent)
            Toast.makeText(this, "SMS Sent", Toast.LENGTH_SHORT)

        }catch (ex: Exception)
        {
            Toast.makeText(this, "Failed to send sms", Toast.LENGTH_SHORT)
            ex.printStackTrace()
        }
    }
    //method for view
    private fun sendByView(){
        val smsVIntent = Intent(ACTION_VIEW)
        smsVIntent.type ="vnd.android-dir/mms-sms"
        smsVIntent.putExtra("number", phoneNumber.text.toString())
        smsVIntent.putExtra("sms_body", smsBody.text.toString())

        //try catch
        try{
            startActivity(smsVIntent)
            Toast.makeText(this, "Message sent", Toast.LENGTH_SHORT)
        }catch (ex: Exception){
            Toast.makeText(this, "Sms failed", Toast.LENGTH_SHORT)
            ex.printStackTrace()

        }

    }

}