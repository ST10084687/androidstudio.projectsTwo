package com.example.validationprojectnew;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edEmail;
    EditText edPassword;
    EditText edConPassword;
    Button btnSubmit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edEmail = findViewById(R.id.editTextTextEmailAddress);
        btnSubmit = findViewById(R.id.button);
        edPassword = findViewById(R.id.editTextTextPassword);
        edConPassword = findViewById(R.id.editTextTextPassword2);
    }
    public void btnValidations (View view)
    {
        String pass = edPassword.getText().toString().trim();
        String passCon = edConPassword.getText().toString().trim();

        if(TextUtils.isEmpty(edEmail.getText().toString())){
            edEmail.setError("Email can't be blank");
            return;
        }
        if (TextUtils.isEmpty(edPassword.getText().toString())){
            edPassword.setError("Password can't be blank");
            return;
        }
        if (TextUtils.isEmpty(edConPassword.getText().toString())){
            edConPassword.setError("Password can't be blank");
            return;
        }
        if (pass.equals(passCon)){
            Toast.makeText(this, "Passwords match! Thanks!", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, "Details submitted", Toast.LENGTH_SHORT).show();
        }

    }
}