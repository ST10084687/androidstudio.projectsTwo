package com.example.apptwo;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // note -- all variables have to be typecasted
    // attached to the design widget that it refers to

        // variables
    TextView tvHeading;
    TextView tvDevName;
    Button btnNotification;
    
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvHeading  = findViewById(R.id.textView);
        tvDevName = findViewById(R.id.textView2);
        btnNotification = findViewById(R.id.button);
    }
    //method to handle the button click event
    public void notificationMethod(View view)
    {
        Toast.makeText(this, "Message from project one", Toast.LENGTH_SHORT).show();
        
    }
}