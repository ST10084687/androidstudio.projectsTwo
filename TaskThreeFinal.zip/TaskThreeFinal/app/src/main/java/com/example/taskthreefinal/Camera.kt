package com.example.taskthreefinal

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.ByteArrayOutputStream

class Camera : AppCompatActivity() {

private var imgViewCamera: ImageView? = null
private var btnTakePic: Button? = null
private var storageRef: StorageReference? = null


@SuppressLint("MissingInflatedId", "SuspiciousIndentation")
override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_camera)

    //typecast
    imgViewCamera = findViewById(androidx.appcompat.R.id.image)
    btnTakePic = findViewById(R.id.btnTakePic)
 storageRef = FirebaseStorage.getInstance().reference


    //on click button
    btnTakePic?.setOnClickListener{CaptureOnClick()}

}//onCreate ends

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        try {
            super.onActivityResult(requestCode, resultCode, data)
            val bm = data?.extras?.get("data") as Bitmap?
            imgViewCamera?.setImageBitmap(bm)

            //conversion to byte array
            val baos = ByteArrayOutputStream()
            bm?.compress(Bitmap.CompressFormat.JPEG, 100, baos)
            val imageData: ByteArray = baos.toByteArray()
            //generated a unique file name
            val fileName = "${System.currentTimeMillis()}.jpg"
            //push the image after formatting to db
            val imageRef = storageRef?.child(fileName)
            val uploadTask = imageRef?.putBytes(imageData)
            uploadTask?.addOnSuccessListener {
                Toast.makeText(this@Camera, "Image saved to online db", Toast.LENGTH_SHORT)

            }?.addOnFailureListener {
                Toast.makeText(this@Camera, "Failed to save image", Toast.LENGTH_SHORT)
            }//failure listener end
        }catch (ex:java.lang.Exception){
            Toast.makeText(this@Camera, "Pic not saved", Toast.LENGTH_SHORT).show()
        }//catch ends
        }//method ends

    //function to capture the on click
    private fun CaptureOnClick(){
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, 0)
    }
}